"""Runtime configuration. Set secrets in Render -> Environment, never in Git."""
import os

def _int(name, default):
    try: return int(os.getenv(name, str(default)))
    except (TypeError, ValueError): return default

def _bool(name, default=True):
    value = os.getenv(name)
    if value is None: return default
    return value.strip().lower() in ("1", "true", "yes", "on")

DATABASE_PATH = os.getenv("DATABASE_PATH", "bot_database.db")
ADMIN_ID = _int("ADMIN_ID", 1242592772)
MIN_DEPOSIT = _int("MIN_DEPOSIT", 15000)
MAX_DEPOSIT = _int("MAX_DEPOSIT", 10000000)
NOTIFICATION_CHANNEL_ID = _int("NOTIFICATION_CHANNEL_ID", -100123456789)
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
BOT_ACTIVE = _bool("BOT_ACTIVE", True)
BALANCE_CACHE_SECONDS = _int("BALANCE_CACHE_SECONDS", 5)

# Provider credentials are loaded from Render Environment Variables.
# API protocol/endpoints must be confirmed from the provider documentation.
MOSTBET_API_KEY = os.getenv("MOSTBET_API_KEY", "").strip()
MOSTBET_API_SECRET = os.getenv("MOSTBET_API_SECRET", "").strip()
MOSTBET_API_BASE_URL = os.getenv("MOSTBET_API_BASE_URL", "").strip().rstrip("/")
XBET_API_KEY = os.getenv("XBET_API_KEY", "").strip()
XBET_API_SECRET = os.getenv("XBET_API_SECRET", "").strip()
XBET_API_BASE_URL = os.getenv("XBET_API_BASE_URL", "").strip().rstrip("/")
MELBET_API_KEY = os.getenv("MELBET_API_KEY", "").strip()
MELBET_API_SECRET = os.getenv("MELBET_API_SECRET", "").strip()
MELBET_API_BASE_URL = os.getenv("MELBET_API_BASE_URL", "").strip().rstrip("/")
BETWINER_API_KEY = os.getenv("BETWINER_API_KEY", "").strip()
BETWINER_API_SECRET = os.getenv("BETWINER_API_SECRET", "").strip()
BETWINER_API_BASE_URL = os.getenv("BETWINER_API_BASE_URL", "").strip().rstrip("/")
WINWIN_API_KEY = os.getenv("WINWIN_API_KEY", "").strip()
WINWIN_API_SECRET = os.getenv("WINWIN_API_SECRET", "").strip()
WINWIN_API_BASE_URL = os.getenv("WINWIN_API_BASE_URL", "").strip().rstrip("/")
