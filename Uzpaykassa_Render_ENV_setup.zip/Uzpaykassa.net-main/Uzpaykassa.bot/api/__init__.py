"""Provider API adapters."""
