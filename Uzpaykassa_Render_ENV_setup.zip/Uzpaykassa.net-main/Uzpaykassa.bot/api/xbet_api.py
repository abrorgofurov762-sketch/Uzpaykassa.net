from config import XBET_API_KEY, XBET_API_SECRET, XBET_API_BASE_URL
from api.base_client import BaseProviderClient

class XBetAPI(BaseProviderClient):
    def __init__(self):
        super().__init__("1xBet", XBET_API_KEY, XBET_API_SECRET, XBET_API_BASE_URL)

xbet_api = XBetAPI()
