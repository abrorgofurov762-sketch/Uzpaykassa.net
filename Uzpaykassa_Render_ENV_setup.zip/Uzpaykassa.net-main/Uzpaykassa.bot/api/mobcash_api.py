"""Compatibility adapters required by existing handlers.
These fail closed until the relevant provider's official API protocol is mapped.
"""
from config import (MELBET_API_KEY, MELBET_API_SECRET, MELBET_API_BASE_URL,
                    BETWINER_API_KEY, BETWINER_API_SECRET, BETWINER_API_BASE_URL,
                    WINWIN_API_KEY, WINWIN_API_SECRET, WINWIN_API_BASE_URL)
from api.base_client import BaseProviderClient

melbet_api = BaseProviderClient("Melbet", MELBET_API_KEY, MELBET_API_SECRET, MELBET_API_BASE_URL)
betwiner_api = BaseProviderClient("Betwiner", BETWINER_API_KEY, BETWINER_API_SECRET, BETWINER_API_BASE_URL)
winwin_api = BaseProviderClient("WinWinBet", WINWIN_API_KEY, WINWIN_API_SECRET, WINWIN_API_BASE_URL)
