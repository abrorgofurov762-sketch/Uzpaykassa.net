from config import MOSTBET_API_KEY, MOSTBET_API_SECRET, MOSTBET_API_BASE_URL
from api.base_client import BaseProviderClient

class MostbetAPI(BaseProviderClient):
    def __init__(self):
        super().__init__("MOSTBET", MOSTBET_API_KEY, MOSTBET_API_SECRET, MOSTBET_API_BASE_URL)

mostbet_api = MostbetAPI()
