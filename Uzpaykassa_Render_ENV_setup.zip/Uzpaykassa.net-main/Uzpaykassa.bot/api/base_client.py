"""Fail-closed base for provider adapters; never reports fake payment success."""
class ProviderNotConfigured(RuntimeError):
    pass

class BaseProviderClient:
    def __init__(self, name, api_key="", api_secret="", base_url=""):
        self.name = name
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url

    def _not_ready(self):
        missing = []
        if not self.api_key: missing.append("API_KEY")
        if not self.api_secret: missing.append("API_SECRET")
        if not self.base_url: missing.append("API_BASE_URL")
        return {"Success": False, "Error": f"{self.name} API is not configured: " + ", ".join(missing) if missing else f"{self.name} API protocol/endpoint mapping is not implemented; provide official API documentation."}

    def get_balance(self): return self._not_ready()
    def find_player(self, player_id): return self._not_ready()
    def deposit_add(self, player_id, amount): return self._not_ready()
    def deposit_payout(self, player_id, payout_code): return self._not_ready()
    def withdraw_subtract(self, player_id, payout_code): return self._not_ready()
    def deposit_player(self, *args, **kwargs): return self._not_ready()
