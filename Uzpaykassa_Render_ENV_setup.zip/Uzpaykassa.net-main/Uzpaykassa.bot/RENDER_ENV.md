# Render Environment Variables

In Render: open your Web Service -> Environment -> Add Environment Variable. Add the values as secret environment variables; do not commit them to GitHub.

Required for bot startup:
- `BOT_TOKEN` = new Telegram bot token from @BotFather
- `ADMIN_ID` = Telegram numeric admin user ID

Recommended:
- `DATABASE_PATH` = `bot_database.db` (note: Render local filesystem may be ephemeral; use a persistent disk or external database for durable state)
- `MIN_DEPOSIT` = `15000`
- `MAX_DEPOSIT` = `10000000`
- `NOTIFICATION_CHANNEL_ID` = your notification channel ID
- `BOT_ACTIVE` = `true`

MOSTBET (fill only with values supplied by the official provider):
- `MOSTBET_API_KEY`
- `MOSTBET_API_SECRET`
- `MOSTBET_API_BASE_URL`

Optional other provider variables:
- `XBET_API_KEY`, `XBET_API_SECRET`, `XBET_API_BASE_URL`
- `MELBET_API_KEY`, `MELBET_API_SECRET`, `MELBET_API_BASE_URL`
- `BETWINER_API_KEY`, `BETWINER_API_SECRET`, `BETWINER_API_BASE_URL`
- `WINWIN_API_KEY`, `WINWIN_API_SECRET`, `WINWIN_API_BASE_URL`

## Important limitations
Environment variables only store credentials; they do not define the provider's API protocol. The adapter methods deliberately return `Success: False` until the official API documentation (endpoint paths, authentication/signature, request/response schema, and permitted operations) is implemented and tested. Do not treat this package as live deposit/withdrawal integration yet.

Security: the source archive contained a hard-coded Telegram bot token. Revoke/rotate it with @BotFather and set the new token only in Render. Never share API secrets or commit them to GitHub.
